import React, { Component } from 'react';
import './styles.css';

class Navigation extends Component{

    render(){
        return <div className="side_bar">

            </div>
    }
}

export default Navigation;