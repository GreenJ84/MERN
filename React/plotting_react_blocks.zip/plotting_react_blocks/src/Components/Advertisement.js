import React, { Component } from 'react';
import './styles.css';

class Advertisement extends Component{

    render(){
        return <div className="ads">

        </div>
    }
}
export default Advertisement;