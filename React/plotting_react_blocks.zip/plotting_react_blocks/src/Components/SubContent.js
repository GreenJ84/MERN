import React, { Component } from 'react';
import './styles.css';

class SubContent extends Component{

    render() {
        return <div className="sub">

            </div>
    }
}

export default SubContent;