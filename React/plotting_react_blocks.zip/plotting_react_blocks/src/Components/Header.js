import React, { Component } from 'react';
import './styles.css';

class Header extends Component{

    render(){
        return <div className="nav">
            </div>
    }
}

export default Header;